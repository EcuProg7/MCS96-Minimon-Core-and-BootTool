import intelhex


ihex = intelhex.IntelHex();

ihex.loadhex("build/BOOTTRY1.HEX");
ihex.tobinfile("build/Boottry1.bin",0x0000, 0xffff)
