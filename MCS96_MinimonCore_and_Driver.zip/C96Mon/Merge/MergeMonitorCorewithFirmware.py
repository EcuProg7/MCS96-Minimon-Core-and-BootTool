import intelhex;
import traceback
import sys

ihex = intelhex.IntelHex();

ihex.loadhex("C96Mon.HEX")

BootStart = 0x40000

firmwareName = input("type name of file to merge with like : 8D0907558M.bin\n")

try:
    firmwareName = str(firmwareName)
    bootfile = open(firmwareName, 'rb');
    bootdata = bootfile.read();
    print(" found firmware !")
    bootfile.close()
    bootihex = intelhex.IntelHex();
    bootihex.frombytes(bootdata, BootStart);
    ihex.merge(bootihex)
    del bootihex

    outputFileName = firmwareName.split(".")[0] + "_mergedWithMonCore.bin"


    ihex.tobinfile(outputFileName, 0x0)
    input("\n merge done, outputfilename: "+outputFileName)
except:
    traceback.print_exc(file=sys.stdout)
    input("file does not exist or other error")


del ihex

