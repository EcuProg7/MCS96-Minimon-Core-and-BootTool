import intelhex


ihex = intelhex.IntelHex();

ihex.loadhex("build/C96Mon.HEX");
ihex.tobinfile("build/C96Mon.bin",0x0000, 0xffff)
del ihex

ihex = intelhex.IntelHex();

ihex.loadhex("build/C96MonA.HEX");
ihex.tobinfile("build/C96Mon_AT_0xC000.bin",0xC000)
del ihex