import intelhex


ihex = intelhex.IntelHex();

ihex.loadhex("build/C96RISM.HEX");
ihex.tobinfile("build/C96RISM.bin",0x0000, 0xffff)
