import intelhex


ihex = intelhex.IntelHex();

ihex.loadhex("build/WFlM38.HEX");   # GetState Driver
ihex.tobinfile("build/WFlM38_GetState.bin",0x0400)
del ihex

ihex = intelhex.IntelHex();

ihex.loadhex("build/WFlEr.HEX");# Erase Driver
ihex.tobinfile("build/WFlM38_EraseSector.bin",0x0400)
del ihex

ihex = intelhex.IntelHex();

ihex.loadhex("build/WFlWr.HEX");# Write Driver
ihex.tobinfile("build/WFlM38_ProgrammFlash.bin",0x0400)
del ihex
