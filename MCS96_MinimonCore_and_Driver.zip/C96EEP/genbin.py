import intelhex


ihex = intelhex.IntelHex();

ihex.loadhex("build/eepread.HEX");   # full Driver
ihex.tobinfile("build/eepM38_rw_0xC000.bin",0xC000)
ihex.tobinfile("build/eepM38_rw_64k.bin",0x0000, 0xFFFF)
del ihex


