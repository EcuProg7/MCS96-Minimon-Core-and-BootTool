
import os;
import serial;
import serial.tools;
import serial.tools.list_ports;
import time;
import sys;
import traceback

def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    base_path = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base_path, relative_path)

def ResetAdapter(ser):
    ser.setDTR(1);
    time.sleep(0.1);
    ser.setDTR(0);
    time.sleep(0.1);

def SetAdapterKKL(ser):
    ser.setDTR(0);
    ser.setRTS(0);
    time.sleep(0.1);


def SendCharwEcho(ser, data):
    #time.sleep(self.sleeptime);
##    now = time.time()
##    while( time.time() < now + self.sleeptime):
##        pass
    ret = True;
    ser.write(data);
    #time.sleep(self.sleeptime);
    echo = ser.read(1)
    if(len(echo) != 0):
        if(echo[0] != data[0]):
            print("echo error sent: ", hex(data[0])," received: ", hex(echo[0]))
            ret = False;
    else:
        print("got no echo")
    return ret;

def SendDatawEcho(ser, data):
##    for d in data:
##        #print("sendDatawEcho char: ", hex(d))
##        SendCharwEcho(ser,[d]);
    ser.write(data);
    echo = ser.read(len(data))

    if(len(echo) != len(data)):
        print("got wrong echo length")
        return False;

    counter = 0
    while counter < len(data):
        if(data[counter] != echo[counter]):
            print("echo error sent: ", hex(data[counter])," received: ", hex(echo[counter]), "at data pos : ", hex(counter))
            ret = False;
        counter += 1

    return True;



def GetAddressAsLittleEndian(address):
    add = [ (address)&0xff, (address>>8)&0xff, (address>>16)&0xff,];
    return add;

def GetWordAsLittleEndian(data):
    add = [ (data)&0xff, (data>>8)&0xff];
    return add;

I_LOADER_STARTED	        = 0x01	#// Loader successfully launched
I_APPLICATION_LOADED	= 0x02	#// Application succ. loaded
I_APPLICATION_STARTED	= 0x03	#// Application succ. launched
I_AUTOBAUD_ACKNOWLEDGE      = 0x04  #// Autobaud detection acknowledge

A_ACK1			    =0xAA  	#// 1st Acknowledge to function code
A_ACK2			    =0xEA	#// 2nd Acknowledge (last byte)
A_ASC1_CON_INIT		    =0xCA	#// ASC1 Init OK
A_ASC1_CON_OK		    =0xD5	#// ASC1 Connection OK

C_WRITE_BLOCK		    =0x84 #// Write memory block to target mem
C_READ_BLOCK		    =0x85 #// Read memory block from target mem
C_EINIT			    =0x31 #// Execute Einit Command
C_SWRESET		   	    =0x32 #// Execute Software Reset
C_GO			    =0x41 #// Jump to user program
C_GETCHECKSUM    	            =0x33 #// get checksum of previous sent block
C_TEST_COMM		   	    =0x93 #// Test communication
C_CALL_FUNCTION		    =0x9F#	// Mon. extension interface: call driver
C_WRITE_WORD		    =0x82 #// write word to memory/register
C_MON_EXT		            =0x9F#	// call driver routine
C_ASC1_CON		      	    =0xCC #// Connection over ASC1
C_READ_WORD	  	      	    =0xCD #// Read Word from memory/register
C_WRITE_WORD_SEQUENCE           =0xCE #// Write Word Sequence
C_CALL_MEMTOOL_DRIVER           =0xCF #// Call memtool driver routine
C_AUTOBAUD		      	    =0xD0 #// Call autobaud routine
C_SETPROTECTION  	            =0xD1 #// Call security function
C_WRITE_BYTE                    = 0x72
C_READ_BYTE                     = 0x73

T_95080                         = 0#
T_95040                         = 1#
T_M93S46_6BIT                   = 2#
T_M93S56_8BIT                   = 3#
T_M93S76_10BIT                  = 4#
T_24C02_8BIT                    = 10#
T_24C04_9BIT                    = 11#
T_29FX00B                       = 20#
T_29FX00B_Simos3                = 21#
T_29FX00BT_EDC15                = 22#



DEV_ID_F400BB     = 0x22ab;
DEV_ID_F800BB     = 0x2258;
DEV_ID_F400BT     = 0x2223;
DEV_ID_F800BT     = 0x22D6;

# M3.8/5.4/5.9 minimon defs
PageRegAddr = 0xe040 
InstPinAddr = 0x1ff5 # 
InstPinResetData = 0xCC
InstPinSetData = 0xCE

#MCS196
P5_DIR          = 0x1ff3;
P5_MODE         = 0x1ff1;
P5_REG          = 0x1ff5;
P5_PIN          = 0x1ff7;

    
P6_PIN          = 0x1FD7
P6_REG          = 0x1FD5
P6_DIR          = 0x1FD3
P6_MODE         = 0x1FD1


p5DirShouldBeData = 0xc0;
p5ModeShouldBeData = 0xCD;


def SendCommand(ser, data):
    SendCharwEcho(ser, data)
    echo = ser.read(1)
    if(len(echo) != 1):
        print("got no command ackn")
        return False;
    if(echo[0] != A_ACK1):
        print("got different response than ackn1: ", hex(echo[0]))
        return False;
    return True;

def SendData(ser, data):
    SendDatawEcho(ser, data)
    echo = ser.read(1)
    if(len(echo) != 1):
        print("got no send data ackn")
        return False;
    if(echo[0] != A_ACK2):
        print("got different response than ackn2: ", hex(echo[0]))
        return False;
    return True;

def GetData(ser, data):
    SendDatawEcho(ser, data)
    echo = ser.read(3)
    if(len(echo) != 3):
        print("got no get data ackn")
        return False, [];
    if(echo[2] != A_ACK2):
        print("got different response than ackn2: ", hex(echo[0]))
        return False, [];
    return True, [echo[0] | echo[1]<<8];

def TestComm(ser):
    print("test comm")
    SendDatawEcho(ser, [C_TEST_COMM])

    data = ser.read(2);
    if(len(data) == 0):
        print("\n no response from ecu after test comm")
        return -1;
    elif(len(data) == 1):
        print("\n only one byte response from ecu after test comm", hex(data[0]))
        return -1;
    elif(data[0] != A_ACK1) | (data[1] != A_ACK2):
        print("\n wrong response from ecu after sending test comm", hex(data[0]),hex(data[1]))
        return -1;
    else:
        print("testcomm successfull")

    print(" got core akn :", hex(A_ACK1), hex(A_ACK2))

def SetWordAtAddress(ser, addr, data):
    ret = SendCommand(ser, [C_WRITE_WORD])
    ret &= SendData(ser, GetAddressAsLittleEndian(addr)+GetWordAsLittleEndian(data))
    if(ret == False):
        print("set Data not successfull 1");
        return False;
    ret , readData = GetWordAtAddress(ser, addr)
    if(ret == False):
        print("set Data not successfull 2");
        return False;
    if(readData[0] != data):
        print("set Data not successfull; set: ",hex(data), "readback: ", hex(readData[0]));
        return False;
    #print("set Data at: ", hex(addr)," success:", ret)
    return True;

def GetWordAtAddress(ser, addr):
    ret = SendCommand(ser, [C_READ_WORD])
    ret , readData = GetData(ser, GetAddressAsLittleEndian(addr))
    if(ret == False):
        print("get Data not successfull");
        return False, [];
    
    #print("get Data at: ", hex(addr)," success:", ret, "data:", hex(readData[0]))
    return True, readData;

def GetByteAtAddress(ser, addr):
    ret = SendCommand(ser, [C_READ_BYTE])
    
    SendDatawEcho(ser, GetAddressAsLittleEndian(addr))
    echo = ser.read(2)
    if(len(echo) != 2):
        print("got no get byte ackn")
        return False, [];
    if(echo[1] != A_ACK2):
        print(" in get Byte at address got different response than ackn2: ", hex(echo[0]))
        return False, [];
    
    #print("get Byte at: ", hex(addr)," success:", ret, "data:", hex(echo[0]))
    return True, [echo[0]];

def SetByteAtAddress(ser, addr, byte):
    ret = SendCommand(ser, [C_WRITE_BYTE])
    
    SendDatawEcho(ser, GetAddressAsLittleEndian(addr)+[byte])
    echo = ser.read(1)
    if(len(echo) != 1):
        print("got no get byte ackn")
        return False;
    if(echo[0] != A_ACK2):
        print(" in get Byte at address got different response than ackn2: ", hex(echo[0]))
        return False;
    ret, echo = GetByteAtAddress(ser, addr)
    return True;


def SetInstPin(ser):
    ser.flushInput()
    success, dataPre = GetByteAtAddress(ser, InstPinAddr)
    if(success == False):
        print("get byte pre in set inst Pin failed")
        return False

    success = SetByteAtAddress(ser, InstPinAddr, InstPinSetData)
    if(success == False):
        print("set byte in set inst Pin failed")
        return False
    success, dataPost = GetByteAtAddress(ser, InstPinAddr)
    if(success == False):
        print("get byte post in set inst Pin failed")
        return False
    print("set inst pin success: ", dataPost[0] == InstPinSetData," data pre: ", hex(dataPre[0]), " post data: ", hex(dataPost[0]) ) 
    return dataPost[0] == InstPinSetData

def ResetInstPin(ser):
    ser.flushInput()
    success, dataPre = GetByteAtAddress(ser, InstPinAddr)
    if(success == False):
        print("get byte pre in reset inst Pin failed")
        return False

    success = SetByteAtAddress(ser, InstPinAddr, InstPinResetData)
    if(success == False):
        print("set byte in reset inst Pin failed")
        return False

    success, dataPost = GetByteAtAddress(ser, InstPinAddr)
    if(success == False):
        print("get byte post in reset inst Pin failed")
        return False
    print("reset inst pin success: ", dataPost[0] == InstPinResetData," data pre: ", hex(dataPre[0]), " post data: ", hex(dataPost[0]) )
    
    return dataPost[0] == InstPinResetData

def SetPage(ser, page, insertPage):
    ser.flushInput()
    page = (page & 0xF) | ((insertPage & 0xF) << 4)
    success, dataPre = GetByteAtAddress(ser, PageRegAddr+1)
    success = SetByteAtAddress(ser, PageRegAddr,page)

    if(success == False):
        print("set page write byte failed")
        return False
    success, data = GetByteAtAddress(ser, PageRegAddr+1)
    print(" set page success: " , (data[0]) == page, " readback: ", (hex(data[0])), " former page: ", hex(dataPre[0]))
    return data[0] == page

def GetPage(ser):
    ser.flushInput()
    success, data = GetByteAtAddress(ser, PageRegAddr+1)
    if(success == False):
        print("get page byte failed")
        return False, []

    return True, data




def GetBlockChecksum(ser):
    SendCharwEcho(ser, [C_GETCHECKSUM])
    echo = ser.read(3)
    if(len(echo) != 3):
        print("got no command ackn")
        return False,[];
    if(echo[2] != A_ACK2):
        print("got different response than ackn2: ", hex(echo[2]))
        return False,[];
    return True,[echo[1]];

def CalcBlockChecksum(data):
    checksum = 0;

    for d in data:
        checksum = (checksum ^ (d))&0xFF

    return checksum

def SetBlockAtAddress(ser, addr, data):
    ret = SendCommand(ser, [C_WRITE_BLOCK])
    ret &= SendData(ser, GetAddressAsLittleEndian(addr)+GetWordAsLittleEndian(len(data))+data)

    ret , checksum = GetBlockChecksum(ser);
    calcChecksum = CalcBlockChecksum(data);
    if(ret == False):
        print("set Block not successfull");
        return False;
    if(calcChecksum != checksum[0]):
        print("get Block at: ", hex(addr),"Wrong Checksum:", ret, " got checksum: ", hex(checksum[0]),
          " is calculated CalcChecksum", hex(calcChecksum) )
        return False,[];
    return True;

def GetBlockAtAddress(ser, addr, size):
    ret = SendCommand(ser, [C_READ_BLOCK])
    SendDatawEcho(ser,  GetAddressAsLittleEndian(addr)+GetWordAsLittleEndian(size))
    echo = ser.read(size+1)
    if(len(echo) != size+1):
        print("GetBlockAtAddress got no ackn: ",echo)
        return False, [];
    if(echo[size] != A_ACK2):
        print("GetBlockAtAddress got different response than ackn2: ", hex(echo[size]))
        return False, [];

    ret , checksum = GetBlockChecksum(ser);
    calcChecksum = CalcBlockChecksum(echo[:size]);
    if(ret == False):
        print("Get Block not successfull, got no checksum ");
        return False,[];
    if(calcChecksum != checksum[0]):
        print("get Block at: ", hex(addr),"Wrong Checksum:", ret, " got checksum: ", hex(checksum[0]),
          " is calculated CalcChecksum", hex(calcChecksum) )
        return False,[];
    return True, echo[:size];

def CallAtAddress(ser, addr, register):     ## 8 register words assumed r8-r15
    ret = SendCommand(ser, [C_CALL_FUNCTION])
    regdata =[]
    for r in register:
        regdata += GetWordAsLittleEndian(r)

    SendDatawEcho(ser, GetAddressAsLittleEndian(addr)+regdata)
    echo = ser.read(17)
    if(len(echo) != 17):
        print("CallAtAddress got no ackn: ",echo)
        return False, [];
    if(echo[16] != A_ACK2):
        print("CallAtAddress got different response than ackn2: ", hex(echo[16]))
        return False, [];

    returnreg = [echo[0] | echo[1]<<8, echo[2] | echo[3]<<8, echo[4] | echo[5]<<8, echo[6] | echo[7]<<8,
                 echo[8] | echo[9]<<8, echo[10] | echo[11]<<8, echo[12] | echo[13]<<8, echo[14] | echo[15]<<8];

##    print(" CallAtAddress at: ", hex(addr)," successfull");#, register after call: ")
##    for r in returnreg:
##        print(hex(r));
    return True, returnreg;

def JumpToUserProg(ser, addr):
    ret = SendCommand(ser, [C_GO])
    SendDatawEcho(ser, GetAddressAsLittleEndian(addr))
    echo = ser.read(1)
    if(len(echo) != 1):
        print("JumpToUserProg got no ackn: ",echo)
        return False;
    if(echo[0] != A_ACK2):
        print("CallAtAddress got different response than ackn2: ", hex(echo[0]))
        return False;

    return True;

def RunFunc(exitt, ser, file, job, startAddr, size, eetype, portAddr8, directionPortAddress8, pinnum, sscType):
    
    ResetAdapter(ser);
    SetAdapterKKL(ser);
    
    ser.reset_input_buffer();
    char = b'';


    driverAddress = 0x00C000;
    DriverEntryPoint = 0x00C000;

    FlashDriverEntryPoint = 0x00F640;


    #driver commands
    C_READSPI = 0x0036;
    C_WRITESPI = 0x0037;

    #flash driver commands
    FC_PROG			=	0x00	; #Program Flash
    FC_ERASE		        =	0x01	; #Erase Flash
    FC_SETTIMING		=	0x03	; #Set Timing
    FC_GETSTATE		        =	0x06	; #Get State
    FC_GETSTATE_ADDR_MANUFID    =       0x00;
    FC_GETSTATE_ADDR_DEVICEID   =       0x01;
    FC_LOCK			=	0x10	; #Lock Flash bank
    FC_UNLOCK		        =	0x11	; #Unlock Flash bank
    FC_PROTECT		        =	0x20	; #Protect entire Flash
    FC_UNPROTECT		=	0x21	; #Unprotect Flash
    FC_BLANKCHECK		=	0x34	; #OTP/ Flash blankcheck
#    FC_GETID		        =	0x35	; #Get Manufacturer ID/ Device ID ->not implemented


#    ;--------------------- Error Values -----------------------------

    E_NOERROR		        =	0x00	; #No error
    E_UNKNOWN_FC		=	0x01	; #Unknown function code

    E_PROG_NO_VPP		=	0x10	; #No VPP while programming
    E_PROG_FAILED		=	0x11	; #Programming failed
    E_PROG_VPP_NOT_CONST	=	0x12	; #VPP not constant while programming

    E_INVALID_BLOCKSIZE	        =	0x1B	; #Invalid blocksize
    E_INVALID_DEST_ADDR	        =	0x1C	; #Invalid destination address

    E_ERASE_NO_VPP		=	0x30	; #No VPP while erasing
    E_ERASE_FAILED		=	0x31	; #Erasing failed
    E_ERASE_VPP_NOT_CONST	=	0x32	; #VPP not constant while erasing

    E_INVALID_SECTOR	        =	0x33	; #Invalid sector number
    E_Sector_LOCKED		=	0x34	; #Sector locked
    E_FLASH_PROTECTED	        =	0x35	; #Flash protected
    
    IntRomAddress = 0x010000;
##    IntRomAddress = 0x000000;

    ExtFlashAddress = 0xc000



    DriverCopyAddress = 0x100;
    BlockLength = 0x100;
    if(size< BlockLength):
        BlockLength = size;


## upload core
    ser.flushInput();
    SendDatawEcho(ser,[0])  #say hello
    byte = ser.read(1);
    if(len(byte) != 1):
        print("\n no response from ecu, Set device into bootmode", byte)
        return -1;
    if(byte[0] == 0xaa):
        print(" core already running\n")

    else:
        print(" core not running, try to restart \n")
        return 99;

    ser.flushInput();
    TestComm(ser);

    #ret = ser.read(10)
    #print(ret)


    #test p5Dir and P5Mode?
        

    ret, p5Dir = GetByteAtAddress(ser, P5_DIR)
    if(p5Dir[0] != p5DirShouldBeData):
        print(" P5Dir is not set from MonCore as needed, should be : ", hex(p5DirShouldBeData), " is in core reg: ", hex(p5Dir[0]))
        exit(2)

    print(" P5Dir set as needed  in core reg: ", hex(p5Dir[0]))

    ret, p5Mode = GetByteAtAddress(ser, P5_MODE)
    if(p5Mode[0] != p5ModeShouldBeData):
        print(" P5Dir is not set from MonCore as needed, should be : ", hex(p5ModeShouldBeData), " is in core reg: ", hex(p5Mode[0]))
        return 2;

    print(" P5Mode set as needed  in core reg: ", hex(p5Mode[0]))

    #scl44 init
    ret = SetByteAtAddress(ser, 0xe02f, 0x41)
    
    ret &= SetByteAtAddress(ser, 0xe030, 0xa)
    ret &= SetByteAtAddress(ser, 0xe031, 0xf)
    ret &= SetByteAtAddress(ser, 0xe032, 0x88)
    ret &= SetByteAtAddress(ser, 0xe042, 0x1)
    ret &= SetByteAtAddress(ser, 0xe040, 0x34)
    ret &= SetByteAtAddress(ser, 0xe01a, 0x3)
    ret &= SetByteAtAddress(ser, 0xe02c, 0x3d)
    #input("after scl init wait")
    ret &= SetPage(ser, 0x3, 3)
    if(ret == False):
        print("got set scl init failed")
        return -1;


    if(job == jobReadEeprom) | (job == jobWriteEeprom):
        driverAddress = 0xc000;
        DriverEntryPoint = driverAddress
        devSel = 0xA0

        if(eetype == T_24C02_8BIT) | (eetype == T_24C04_9BIT) :
            path = resource_path("Drivers/eepM38_rw_0xC000.bin");
            eepromDriverFile = open(path, 'rb')
            eepromDriver = list(eepromDriverFile.read());
            eepromDriverFile.close()
        else:
            print("wrong type in run func")
            return -1;
    
        print("sending eeprom driver")
        ResetInstPin(ser)
        SetPage(ser, 3,3)
        SetBlockAtAddress(ser,driverAddress, eepromDriver)
        if(ret == False):
            print("send eeprom driver failed")
            return -1;

        #setup port pins scl and sda
        ret, byte = GetByteAtAddress(ser, P6_DIR)
        byte = byte[0] | 0x20      #; set bit 5 in P6Dir to have open drain output, high input
        byte = byte & 0xEF      #; clear bit 4 to have scl as push pull output
        ret &= SetByteAtAddress(ser, P6_DIR, byte)
        if(ret == False):
            print("set port direction failed")
            return -1;

        ret, byte = GetByteAtAddress(ser, P6_MODE)
        byte = byte[0] & 0xCF      #; clear bit 4 and 5 in P6Mode to have P6.4 and P6.5 as port pin
        ret &= SetByteAtAddress(ser, P6_MODE, byte)
        if(ret == False):
            print("set port mode failed")
            return -1;

        ret, byte = GetByteAtAddress(ser, P6_REG)
        byte = byte[0] | 0x30      #; set bit 4 and 5 in P6_REG for P6.4 and P6.5 ?
        ret &= SetByteAtAddress(ser, P6_REG, byte)
        if(ret == False):
            print("set port REg failed")
            return -1;

        ret = SetByteAtAddress(ser, 0x405, eetype)   #set eep type (10 or 11)
        ret &= SetByteAtAddress(ser, 0x406, devSel)   #set devsel (enable bits according to ex pins tied)        
        #set port reg and Pin address and masks
        ret &= SetWordAtAddress(ser, 0x408, P6_REG)   #P6_REG address
        ret &= SetWordAtAddress(ser, 0x40A, P6_PIN)   #P6_PIN address
        ret &= SetByteAtAddress(ser, 0x40C, 0x10)   #mask of pin 6.4 scl
        ret &= SetByteAtAddress(ser, 0x40D, 0x20)   #mask of pin 6.5 sda
        ret &= SetByteAtAddress(ser, 0x40E, 0x05)   #right shift of pin 6.5 sda
        #input("swker")
        if(ret == False):
                print("set driver run parameter failed 1")
                return -1;
    
    if(job == jobReadEeprom):
        print("\n *************  start read  *************\n ")
        
        offset = 0x00;
        BlockLength = 0x80
        readSize = BlockLength
        DriverCopyAddress = 0x0420

        

        while (offset < size):
            if(readSize > (size - offset)):
                readSize = (size - offset)

            ret = SetWordAtAddress(ser, 0x400, offset)   #eep address
            ret &= SetByteAtAddress(ser, 0x407, C_READSPI)   #set read command; overwritten with return code

            ret &= SetWordAtAddress(ser, 0x402, DriverCopyAddress)   #set ram buffer address
            ret &= SetByteAtAddress(ser, 0x404, readSize)   #set readsize
            
            
            if(ret == False):
                print("set driver run parameter failed 2")
                return -1;

            success = JumpToUserProg(ser, DriverEntryPoint)
            if(success == False):
                print(" Call FC_ReadEEp failed")
                return -1;
            else:
                print(" Call FC_ReadEEp success on offset: ", hex(offset))
            
            ret, retdata = GetByteAtAddress(ser, 0x407)
            if(retdata[0] !=0):
                print("driver failed with code: ", hex(retdata[0]))
                return 1;


            success, blockData = GetBlockAtAddress(ser, DriverCopyAddress, readSize)
            

            if(success == True):
                file.write(bytes(blockData));
            else:
                print(" read not successfull!!");

            offset += readSize;




        print(" \n********** read END!! ***********\n");
        return 1;


    elif(job == jobWriteEeprom):
        print("\n *************  start write  *************\n ")
        
        offset = 0x0;
        writeData = file.read();
        size = len(writeData);

        if((eetype == T_24C02_8BIT) | (eetype == T_24C04_9BIT)):
            BlockLength = 0x20

        DriverCopyAddress = 0x0420
        

        while (offset < size):
            writeSize = BlockLength;
            if(writeSize > (size - offset)):
                writeSize = (size - offset);

            ret = SetWordAtAddress(ser, 0x400, offset)   #eep address
            ret &= SetByteAtAddress(ser, 0x407, C_WRITESPI)   #set write command; overwritten with return code

            ret &= SetWordAtAddress(ser, 0x402, DriverCopyAddress)   #set ram buffer address
            ret &= SetByteAtAddress(ser, 0x404, writeSize)   #set writesize
            
            
            if(ret == False):
                print("set driver run parameter failed 2")
                return -1;

            success = SetBlockAtAddress(ser, DriverCopyAddress, list(writeData[offset:(offset+writeSize)]))
            

            if(success != True):
                print(" write data into ram not successfull!!");
                return -1;

            success = JumpToUserProg(ser, DriverEntryPoint)
            if(success == False):
                print(" Call FC_WriteEEp failed")
                return -1;
            else:
                print(" Call FC_WriteEEp success on offset: ", hex(offset))
                
            
            ret, retdata = GetByteAtAddress(ser, 0x407)
            if(retdata[0] !=0):
                print("driver failed with code: ", hex(retdata[0]))
                return 1;



            offset += writeSize;

        print(" \n********** write END!! ***********\n");

        print("\n *************  start verify  *************\n ")
        
        offset = 0x00;
        BlockLength = 0x80
        readSize = BlockLength
        verifyData = [];

        while (offset < size):

            if(readSize > (size - offset)):
                readSize = (size - offset)

            ret = SetWordAtAddress(ser, 0x400, offset)   #eep address
            ret &= SetByteAtAddress(ser, 0x407, C_READSPI)   #set read command; overwritten with return code

            ret &= SetWordAtAddress(ser, 0x402, DriverCopyAddress)   #set ram buffer address
            ret &= SetByteAtAddress(ser, 0x404, readSize)   #set readsize
            
            
            if(ret == False):
                print("set driver run parameter failed 2")
                return -1;

            success = JumpToUserProg(ser, DriverEntryPoint)
            if(success == False):
                print(" Call FC_ReadEEp failed")
                return -1;
            else:
                print(" Call FC_ReadEEp success on offset: ", hex(offset))
            
            ret, retdata = GetByteAtAddress(ser, 0x407)
            if(retdata[0] !=0):
                print("driver failed with code: ", hex(retdata[0]))
                return 1;


            success, blockData = GetBlockAtAddress(ser, DriverCopyAddress, readSize)
            
            if(success == True):
                verifyData += blockData
            else:
                print(" verify not successfull!!");

            offset += BlockLength;

        offset = 0x0;
        writeData = list(writeData)
        while (offset < size):
            if(writeData[offset] != verifyData[offset]):
                print("write data not equal verify data at pos: ", hex(offset))

            offset += 1;

        print(" \n********** verify END!! ***********\n");

        
        return 1;
        
       

    if(job == jobWriteExtFlash):
        writeAddressBase = 0xc000
        driverAddress = 0x400
        FlashDriverEntryPoint = 0x408

        botBootSector = False;
        
        ResetInstPin(ser)

        

        

        path = resource_path("Drivers/WFlM38_GetState.bin");
        eepromDriverFile = open(path, 'rb')

        eepromDriver = list(eepromDriverFile.read());
        eepromDriverFile.close()
                
        print("sending getstate driver")
        SetBlockAtAddress(ser,driverAddress, eepromDriver)
        
        print("\n *************  start write extFlash  *************\n ")



##        print("\n *************  write reset to read (f0)  *************\n ")
##        SetWordAtAddress(ser, 0x400000, 0xf0);

##        GetFlashManufacturerID(ser);
        
#************* get IDS *********
        ResetInstPin(ser)
        SetPage(ser, 0x3, 3)
        SetInstPin(ser)

        success = JumpToUserProg(ser, FlashDriverEntryPoint)
        if(success == False):
            print(" Call FC_GETSTATE failed")
            return -1;
        print("jump to user success: ", success)

        ser.flushInput()
        ret, data = GetWordAtAddress(ser, 0x400)
        print("manufacturer id: ", hex(data[0]))

        ret, data = GetWordAtAddress(ser, 0x402)
        print("Device id: ", hex(data[0]))

        devId = data[0]
        flashSize = 0

        if(devId == DEV_ID_F800BB):
            print("F800BB Flash 1024kBit found, only 256k of flash is usable");
            flashSize = (1<<18) #only 256k of flash is usable
        elif(devId == DEV_ID_F400BB):
            print("F400BB Flash 512kBit found");
            
            flashSize = (1<<18) #only 256k of flash is usable
        elif(devId == DEV_ID_F800BT):
            print("F800BT Flash 1024kBit found");
            botBootSector = False;
            flashSize = (1<<18) #only 256k of flash is usable
        elif(devId == DEV_ID_F400BT):
            print("F400BT Flash 512kBit found");
            botBootSector = True;   #top boot sectors in data range
            flashSize = (1<<18) #only 256k of flash is usable
        else:
            input("no F400Bx or F800Bx AMD id, press STRG + C to end or ENTER to continue\n")
            flashSize = size

        if(size < flashSize):
           print("filesize: ", size/1024," kB is smaller than usable flash size: ", flashSize/1024," kB (should be no problem) !!!!!\n")
        if(size > flashSize):
           input("filesize: ", size/1024," kB is bigger than usable flash size: ", flashSize/1024," kB !!!!!, press STRG + C to end or ENTER to continue\n")
        
        offset = 0x0;

        # read data to know size
        writeData = file.read();
        size = len(writeData);

        #************* erase sectors *********

        path = resource_path("Drivers/WFlM38_EraseSector.bin");
        eepromDriverFile = open(path, 'rb')

        eepromDriver = list(eepromDriverFile.read());
        eepromDriverFile.close()
                
        print("\nsending erase sector driver")
        SetBlockAtAddress(ser,driverAddress, eepromDriver)

        pagecounter = 0

        while(pagecounter < 16):

            ResetInstPin(ser)
            SetPage(ser, pagecounter, 3)
            SetInstPin(ser)

            ret = SetWordAtAddress(ser, 0x402, 4)   #set 4 pages to erase (64k)
            ret = SetWordAtAddress(ser, 0x400, 0)   #set 4 full pages to erase (0xc000 - > 0x0000)

            success = JumpToUserProg(ser, FlashDriverEntryPoint)
            if(success == False):
                print(" Call FC_EraseSector failed")
                return -1;
            print("jump to user success: ", success)

    ##        ser.flushInput()
    ##        ret, data = GetWordAtAddress(ser, 0x400)
    ##        print("manufacturer id: ", hex(data[0]))

            ret, data = GetByteAtAddress(ser, 0x404)
            print("erase sector success: ", data[0] == 0)
            if(data[0] !=0):
                print("erase failed with code: ", hex(data[0]))
                return 1;

            ResetInstPin(ser)
            ret, actPage = GetPage(ser)

            pagecounter += 4
            print("act page after erase: ", hex(actPage[0]), "should be page ", hex(pagecounter), (actPage[0] & 0xF)==(pagecounter & 0xF))



#************* Write Blocks *********

        path = resource_path("Drivers/WFlM38_ProgrammFlash.bin");
        eepromDriverFile = open(path, 'rb')

        eepromDriver = list(eepromDriverFile.read());
        eepromDriverFile.close()
                
        print("\nsending programm block driver")
        SetBlockAtAddress(ser,driverAddress, eepromDriver)

        #************* Write*********
        print("\n")
        offset = 0x0;
        page = 0
        
        writesize = BlockLength;
        ResetInstPin(ser)
        SetPage(ser, 0, 3)
        SetInstPin(ser)
        pageEnd = 0x3FFF+ (page<<14)

        ret = SetWordAtAddress(ser, 0x404, DriverCopyAddress)   #set source address of data

        while (offset < size):
            if((size - offset) < BlockLength):
                writesize = (size - offset);
            
            if(offset > pageEnd):
                page += 1
                ResetInstPin(ser)
                SetPage(ser, page, 3)
                SetInstPin(ser)
                pageEnd = 0x3FFF+ (page<<14)
            
            blockData = writeData[offset:(offset+writesize)];
            write = False;
            for e in blockData:
                if(e != 0xff):
                    write = True;
            if (write == True):
                success = SetBlockAtAddress(ser, DriverCopyAddress, list(writeData[offset:(offset+writesize)]))

                if(success != True):
                    print("write Data Block to Ram At 0x100 - 0x1ff not successfull!!");
                    return -1;

                writeAddress = ExtFlashAddress+(offset & 0x3FFF)

                ret = SetWordAtAddress(ser, 0x400, writeAddress)   #set flash write address (0xc000 - > 0xffff)
                ret = SetWordAtAddress(ser, 0x402, writesize)   #set write size

                success = JumpToUserProg(ser, FlashDriverEntryPoint)
                if(success == False):
                    print(" Call FC_Programm Block failed")
                    return -1;
                
                ret, retdata = GetByteAtAddress(ser, 0x406)
                if(retdata[0] !=0):
                    print("write failed with code: ", hex(data[0]))
                    return 1;
                
                offset += writesize;
                sys.stdout.write("\rCall FC_PORGRAMM BLOCK "+ str(hex(offset)) +" successfull: "  + str(retdata== 0x0)+" ; finished " + str(int(offset *100 / size)) +" % ")
            else:
                offset += writesize;
                sys.stdout.write("\r only 0xff in block -> nothing to write "+" ; finished " + str(int(offset *100 / size)) +" % ")

        
        print(" \n********** write extFlash successfull!! ***********\n");
        return 1;

    if(job == jobReadExtFlash):
        print("\n *************  start read extFlash  *************\n\n")
        
        offset = 0x0;
        page = 0
        readsize = BlockLength;
        ExtFlashAddress = 0xc000
        ResetInstPin(ser)
        SetPage(ser, 0, 3)
        SetInstPin(ser)
        pageEnd = 0x3FFF+ (page<<14)

        while (offset < size):
            if(offset > pageEnd):
                page += 1
                ResetInstPin(ser)
                SetPage(ser, page, 3)
                SetInstPin(ser)
                pageEnd = 0x3FFF+ (page<<14)
        
            if((size - offset) < BlockLength):
                readsize = (size - offset);
            success, blockData = GetBlockAtAddress(ser, ExtFlashAddress+(offset & 0x3FFF), readsize)
            

            if(success == True):
                file.write(bytes(blockData));
            else:
                print(" read extFlash not successfull!!");
                return 1;
            
            offset += readsize;
            sys.stdout.write("\r  read at "+ str(hex(offset)) +" ; finished " + str(int(offset *100 / size)) +" % ")


        print(" \n********** read extFlash successfull!! ***********\n");
        return 1;

    return 1;   # != 0 ... exit

def PrintUsage():
    print(" type -h for this help\n Arguments in [] are optional:\n"+
          
          "\n-------------------- Read EEProm--------------------\n"+
          "    ME7BootTool  baudrate  -readeeprom -PeriphType  eepromtype size(hex or dezimal)  [filename]    \n"+
          "eg: ME7BootTool  9600     -readeeprom -I2C          10               0x200                 551Eeprom.ori\n"+
          "----------------------------------------------------\n"+

          "\n-------------------- Write EEProm--------------------\n"+
          "    ME7BootTool  baudrate  -writeeeprom -PeriphType eepromtype filename                           \n"+
          "eg: ME7BootTool  9600     -writeeeprom -I2C         10            551ImmoOff.bin\n"+
          "----------------------------------------------------\n"+
          
          "\n-------------------- Parameters for R/W EEProm--------------------\n"+
          "10 for 24c02 with 8bit address, 11 for 24c04 with 9bit address \n\n"+
          " -PeriphType : -I2C for M3.2 / M3.8 / M5.4 / M5.9 (only type 10 and 11 supported)\n"+
          "----------------------------------------------------\n"+
          
          
          "\n-------------------- read external Flash --------------------\n"+
          "     ME7BootTool  baudrate  -readextflash   size(hex or dezimal)  [filename]  \n"+
          " eg: ME7BootTool  9600     -readextflash   0x80000                551extFlash.ori\n"+
          "----------------------------------------------------\n"+
          
          "\n-------------------- write external Flash --------------------\n"+
          "     ME7BootTool  baudrate  -writeextflash  filename   \n"+
          "eg:  ME7BootTool  9600     -writeextflash  551extFlash.bin         "+
          "----------------------------------------------------\n"+
          
          "\n-------------------- Baudrate --------------------\n"+
          " standard rates: fixed in minimon: 9600 on M3.8.2 @ 12Mhz");

def GetPort(argPort , argPin):
    portAddr8 = P6_REG;
    directionPortAddress8 = P6_DIR;
    pinnum = 7;

    if(argPort.lower().find("port5") != -1):
        portAddr8 = P5_REG;
        directionPortAddress8 = P5_DIR;

    elif(argPort.lower().find("port6") != -1):
        portAddr8 = P6_REG;
        directionPortAddress8 = P6_DIR;


    if(argPin.lower().find("pin0") != -1):
        pinnum = 0;
    elif(argPin.lower().find("pin1") != -1):
        pinnum = 1;
    elif(argPin.lower().find("pin2") != -1):
        pinnum = 2;
    elif(argPin.lower().find("pin3") != -1):
        pinnum = 3;
    elif(argPin.lower().find("pin4") != -1):
        pinnum = 4;
    elif(argPin.lower().find("pin5") != -1):
        pinnum = 5;
    elif(argPin.lower().find("pin6") != -1):
        pinnum = 6;
    elif(argPin.lower().find("pin7") != -1):
        pinnum = 7;
    elif(argPin.lower().find("pin8") != -1):
        pinnum = 8;
    elif(argPin.lower().find("pin9") != -1):
        pinnum = 9;
    elif(argPin.lower().find("pin10") != -1):
        pinnum = 10;
    elif(argPin.lower().find("pin11") != -1):
        pinnum = 11;
    elif(argPin.lower().find("pin12") != -1):
        pinnum = 12;
    elif(argPin.lower().find("pin13") != -1):
        pinnum = 13;
    elif(argPin.lower().find("pin14") != -1):
        pinnum = 14;
    elif(argPin.lower().find("pin15") != -1):
        pinnum = 15;
    else:
        return False, portAddr8, directionPortAddress8, pinnum;
        
    return True , portAddr8, directionPortAddress8, pinnum;
    


exitt = 0;
usbthere = 0;
state = 0;
printwait = 0;
ports = [];
filename = "eeprom.bin";
file = [];
job = 0;
jobReadEeprom = 1;
jobWriteEeprom = 3;
jobReadExtFlash = 5;
jobWriteExtFlash = 6;
size = 0x200;

baud = 9600;
startAddr = -1;

portAddr8 = P6_REG;
directionPortAddress8 = P6_DIR;
pinnum = 7;

eetype = 0;
sscTypeX = 1;
i2cType = 2;
sscType = 0;

def  ParsePeriphType(typeString, x_sscArgLength, i2cArgLength):

    expectedArgSize = x_sscArgLength
##    if(sys.argv[3].lower().find("-xssc") != -1):
##        sscType = sscTypeX;
##        print("XC16x & ST10 XSSC is used")
##    elif(sys.argv[3].lower().find("-ssc") != -1):
##        sscType = 0;
##        print("C16x SSC is used")
    if(sys.argv[3].lower().find("-i2c") != -1):
        sscType = i2cType;
        print("Sw I2C is used")
        expectedArgSize = i2cArgLength
    else:
        return False, expectedArgSize, sscType
    return True, expectedArgSize, sscType

def  ParseEEType(eetypeArg, sscType):
    #type
    try:
        eetype = int(eetypeArg);
    except:
        try:
            eetype = int(eetypeArg,16);
        except:
            return False, 0

##    if(eetype == T_95080):
##        print(" eeprom type is 95080 to 95320");
##    elif(eetype == T_95040):
##        print(" eeprom type is 95040 or 5P08C3");
##    elif(eetype == T_M93S46_6BIT):
##        print(" eeprom type is M93S46 6BIT address");
##    elif(eetype == T_M93S56_8BIT):
##        print(" eeprom type is M93S56 or M93S66 8BIT address");
##    elif(eetype == T_M93S76_10BIT):
##        print(" eeprom type is M93S76 or M93S86 10BIT address");
    if(eetype == T_24C02_8BIT):
        print(" eeprom type is 24C02");
    elif(eetype == T_24C04_9BIT):
        print(" eeprom type is 24c04");
    else:
        return False, 0

    if(sscType == i2cType):
        if((eetype != T_24C02_8BIT) & (eetype != T_24C04_9BIT)):
            print("i2c only with eetype 10 and 11 supported")
            return False, 0
    else:
        if((eetype == T_24C02_8BIT) | (eetype == T_24C04_9BIT)):
            print("ssc or xssc not with eetype 10 and 11 supported")
            return False, 0
    return True, eetype

print("\nBootMode Tool for m3.2 / M3.8 / M5.4 / M5.9 inspired by ArgDub , 360trev and Gremlin \n***********\n")
while(exitt==0):
    try:
        if state == 0:
            if(len(sys.argv) <3):
                PrintUsage();
                break;

            try:
                baud = int(sys.argv[1]);
                opt1 = str(sys.argv[2])

                print(opt1," baudrate: ", baud)



                
                if(opt1.lower().find("readextflash") != -1):     ################################### READ ext FLASH
                    if(len(sys.argv) <4):
                        print("no size given!!!!\n");
                        PrintUsage();
                        break;
                    
                    if(len(sys.argv) <5):
                        filename = "bins/extFlash.bin";
                        print("no filename given, bins/extFlash.bin is used\n");
                    else:
                        filename = str(sys.argv[4])
                    try:
                        size = int(sys.argv[3]);
                    except:
                        try:
                            size = int(sys.argv[3],16);
                        except:
                            print("wrong argument for size")
                            PrintUsage();
                            break;

                    print(" size: ", int(size / 1024), " kB")
                    

                    job = jobReadExtFlash;
                    state = 10;
                    file = open(filename,'wb');

                elif(opt1.lower().find("writeextflash") != -1):     ################################### Write ExtFlash
                    if(len(sys.argv) <4):
                        print("no  filename and Flash /ECU type given !!!!\n");
                        PrintUsage();
                        break;
                    

                    else:
                        filename = str(sys.argv[3])
                    try:
                        file_stats = os.stat(filename);
                    except:
                        print("wrong filename or not existent ?!? \n");
                        PrintUsage();
                        break;


                    size = file_stats.st_size;


                    print(" size: ", int(size / 1024), " kB")
                    

                    job = jobWriteExtFlash;
                    state = 10;
                    file = open(filename,'rb');
                    
                    
                elif(opt1.lower().find("readeeprom") != -1):     ################################### READ eeprom
                    if(len(sys.argv) <6):
                        print("too few arguments .. !!!!\n");
                        PrintUsage();
                        break;
                    expectedArgSize = 9
                    
                    success, expectedArgSize, sscType = ParsePeriphType(sys.argv[3].lower(), 9, 7);

                    if(success == False):
                        print("wrong argument for peripheral type")
                        PrintUsage();
                        break;
                        
                    #type
                    success, eetype = ParseEEType(sys.argv[4], sscType);
                    if(success == False):
                        print("wrong argument for type")
                        PrintUsage();
                        break;


                    

                    if(sscType == i2cType):
                        inputPort = "Port4"     #not used in i2c
                        inputPin = "pin7"     #not used in i2c
                    else:
                        inputPort = sys.argv[5]
                        inputPin = sys.argv[6]

                    #parse chip slect for spi devices
                    success , portAddr8, directionPortAddress8, pinnum = GetPort(inputPort,inputPin)
                    if(success == False):
                        print("port or pin wrong parsed \n")
                        PrintUsage();
                        break;
                    
                    if(len(sys.argv) <expectedArgSize):
                        filename = "bins/eeprom.bin";
                        print("no filename given, bins/eeprom.bin is used\n");
                    else:
                        filename = str(sys.argv[expectedArgSize-1])

                    #size argument
                    try:
                        size = int(sys.argv[expectedArgSize-2]);
                    except:
                        try:
                            size = int(sys.argv[expectedArgSize-2],16);
                        except:
                            print("wrong argument for size")
                            PrintUsage();
                            break;
                        
                    print("read size: ", hex(size))

                    job = jobReadEeprom;
                    state = 10;
                    file = open(filename,'wb');


                elif(opt1.lower().find("writeeeprom") != -1) :     ################################### write eeprom
                    
                    if(len(sys.argv) <5):
                        print("too few arguments .. !!!!\n");
                        PrintUsage();
                        break;
                    expectedArgSize = 8

                    success, expectedArgSize, sscType = ParsePeriphType(sys.argv[3].lower(), 8, 6);

                    if(success == False):
                        print("wrong argument for peripheral type")
                        PrintUsage();
                        break;
                        
                    #type
                    success, eetype = ParseEEType(sys.argv[4], sscType);
                    if(success == False):
                        print("wrong argument for type")
                        PrintUsage();
                        break;
                    
                    if(len(sys.argv) <expectedArgSize):
                        print("no filename given\n");
                        PrintUsage();
                        break;
                    else:
                        filename = str(sys.argv[expectedArgSize-1])

                    # check if file is existent and print size
                    try:
                        file_stats = os.stat(filename);
                    except:
                        print("wrong filename or not existent ?!? \n");
                        PrintUsage();
                        break;
                    
                    size = file_stats.st_size;
                    print(" file size: ", size, " B")

                    if(sscType == i2cType):
                        inputPort = "Port4"
                        inputPin = "pin7"
                    else:
                        inputPort = sys.argv[5]
                        inputPin = sys.argv[6]
                        
                    success , portAddr8, directionPortAddress8, pinnum = GetPort(inputPort,inputPin)
                    if(success == False):
                        print("port or pin wrong parsed \n")
                        PrintUsage();
                        break;

                    job = jobWriteEeprom;
                    state = 10;
                    file = open(filename,'rb');
                else:
                    print("wrong main command parsed (writeeeprom, readextflash ....) ")
                    PrintUsage();
                    exitt = 1;
            except:
                print("wrong arguments for baudrate or main command(writeeeprom, readextflash ....)")
                traceback.print_exc()
                PrintUsage();
                exitt = 1;
        
        elif state == 10:
            if printwait == 0:
                print("Waiting for K+Can or KKL Adapter (plug in USB if not done!!)");
                printwait = 1;
            while (usbthere == 0):
                
                time.sleep(1);
                usbPort = serial.tools.list_ports.grep("USB Serial Port");
                
                for port in usbPort:
                    ports += [port];
                    #print(port);
                    usbthere = 1;
                    state = 11;
                    printwait = 0;
                    
        elif state == 11:
            comcounter = 0;
        
            if(len(ports) > 1):
                
                while(comcounter < len(ports)):
                    print("num: ",comcounter," : ", ports[comcounter]);
                    comcounter +=1;
                num = input("type com to use ( pos number)");
                try:
                    comcounter = int(num);
                    if( comcounter > len(ports)) | (comcounter < 0):
                        print("wrong input");
                        usbthere = 0;
                        state = 10;
                        ports = [];
                except:
                    print("wrong input");
                    usbthere = 0;
                    state = 10;
                    ports = [];
            if(usbthere == 1):
                print("using ", ports[comcounter].device,"\n");
                ser=serial.Serial(ports[comcounter].device, baud,timeout=1)
                ser.reset_input_buffer();
                state = 20;

        elif state == 20:
            try:
                exitt = RunFunc(exitt, ser, file, job, startAddr, size, eetype, portAddr8, directionPortAddress8, pinnum, sscType);
            except:
                exitt = -1;
                traceback.print_exc()
                print("kb-hit or exception exit")
            
    except :
        exitt = 1;
        traceback.print_exc()
        print("kb-hit or exception exit")
try:
    ser.close();
    file.close();
except:
    pass


